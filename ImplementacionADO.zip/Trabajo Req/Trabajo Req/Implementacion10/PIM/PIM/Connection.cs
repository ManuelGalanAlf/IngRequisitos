﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    class Connection
    {
        protected string server = " database-minipim.cdwgeayaeh1v.eu-central-1.rds.amazonaws.com";

        protected string database = "grupo17DB";

        protected string user = "grupo17";

        protected string password = "FCE9BRhKnDKMUNb5"; 
    }
}
